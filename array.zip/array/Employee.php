<!DOCTYPE html>
<html>
<head>
    <title>Employee Search</title>
    <script>
        function suggestNames() {
            let input = document.getElementById("employee_name").value.toLowerCase();
            let datalist = document.getElementById("suggestions");
            datalist.innerHTML = "";
            
            let employees = [
                "John Doe", "Jane Smith", "Robert Brown", "Emily Davis", "Michael Wilson",
                "Sarah Johnson", "David Miller", "Laura Garcia", "James Martinez", "Anna Thompson"
            ];
            
            employees.forEach(name => {
                if (name.toLowerCase().includes(input) && input !== "") {
                    let option = document.createElement("option");
                    option.value = name;
                    datalist.appendChild(option);
                }
            });
        }
    </script>
</head>
<body>
    <h2>Search for an Employee</h2>
    <form method="post">
        <input type="text" id="employee_name" name="employee_name" placeholder="Enter Employee Name" required oninput="suggestNames()" list="suggestions">
        <datalist id="suggestions"></datalist>
        <button type="submit">Search</button>
    </form>

    <?php
    // 2D array of employees with multiple columns (ID, Name, Department)
    $employees = [
        ["ID" => 101, "Name" => "John Doe", "Department" => "HR"],
        ["ID" => 102, "Name" => "Jane Smith", "Department" => "Finance"],
        ["ID" => 103, "Name" => "Robert Brown", "Department" => "IT"],
        ["ID" => 104, "Name" => "Emily Davis", "Department" => "Marketing"],
        ["ID" => 105, "Name" => "Michael Wilson", "Department" => "Sales"],
        ["ID" => 106, "Name" => "Sarah Johnson", "Department" => "HR"],
        ["ID" => 107, "Name" => "David Miller", "Department" => "Finance"],
        ["ID" => 108, "Name" => "Laura Garcia", "Department" => "IT"],
        ["ID" => 109, "Name" => "James Martinez", "Department" => "Marketing"],
        ["ID" => 110, "Name" => "Anna Thompson", "Department" => "Sales"]
    ];
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $search_name = trim($_POST["employee_name"]);
        $found = false;
        
        foreach ($employees as $employee) {
            if ($employee["Name"] === $search_name) {
                echo "<p style='color:green;'>Employee '{$employee["Name"]}' found in the '{$employee["Department"]}' department.</p>";
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            echo "<p style='color:red;'>Employee '$search_name' not found.</p>";
        }
    }
    ?>
</body>
</html>
