<?php
include "db.php";

// Query to fetch all books
$query = "SELECT * FROM books";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $books = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $books = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books Catalog</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <h1>Books Catalog</h1>
    
    <div class="book-list">
        <?php if (count($books) > 0): ?>
            <?php foreach ($books as $book): ?>
                <div class="book">
                    <h3><?php echo $book['title']; ?></h3>
                    <p><strong>Author:</strong> <?php echo $book['author']; ?></p>
                    <p><strong>Year:</strong> <?php echo $book['publication_year']; ?></p>
                    <p><strong>Genre:</strong> <?php echo $book['genre']; ?></p>
                    <p><strong>Description:</strong> <?php echo $book['description']; ?></p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No books available in the catalog.</p>
        <?php endif; ?>
    </div>

</body>
</html>
