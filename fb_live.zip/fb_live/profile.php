<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['post_text'])) {
    $post_text = $_POST['post_text'];
    $query = "INSERT INTO posts (user_id, post_text) VALUES ('$user_id', '$post_text')";
    if ($conn->query($query) === TRUE) {
        echo "Post published successfully.";
    } else {
        echo "Error: " . $conn->error;
    }
}

$posts = $conn->query("SELECT posts.*, users.username FROM posts INNER JOIN users ON posts.user_id = users.id ORDER BY posts.created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Welcome, <?= $username ?>!</h2>
    <form method="POST">
        <textarea name="post_text" placeholder="What's on your mind?" required></textarea><br><br>
        <button type="submit">Post</button>
    </form>
    
    <h3>Your Posts:</h3>
    <?php while ($post = $posts->fetch_assoc()): ?>
        <div class="post">
            <strong><?= $post['username'] ?></strong><br>
            <?= $post['post_text'] ?><br>
            <small><?= $post['created_at'] ?></small>
        </div>
    <?php endwhile; ?>
    <a href="logout.php">Logout</a>
</body>
</html>
