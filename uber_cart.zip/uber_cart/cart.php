<?php include "db.php"; session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Your Cart</title>
</head>
<body>
  <h2>Shopping Cart</h2>
  <?php
  if (empty($_SESSION['cart'])) {
    echo "Your cart is empty.";
  } else {
    $total = 0;
    $ids = implode(",", $_SESSION['cart']);
    $res = $conn->query("SELECT * FROM products WHERE id IN ($ids)");
    while($row = $res->fetch_assoc()) {
      echo "<p>{$row['name']} - ₹{$row['price']}</p>";
      $total += $row['price'];
    }
    echo "<hr><strong>Total: ₹$total</strong><br><br>";
    echo "<a href='checkout.php'>Proceed to Checkout</a>";
  }
  ?>
</body>
</html>
