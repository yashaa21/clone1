CREATE DATABASE ubercart;
USE ubercart;

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    price DECIMAL(10,2),
    image VARCHAR(255)
);

INSERT INTO products (name, price, image) VALUES
('T-Shirt', 499.00, 'images/tshirt.jpg'),
('Jeans', 899.00, 'images/jeans.jpg'),
('Shoes', 1200.00, 'images/shoes.jpg');
