<?php include "db.php"; session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Ubercart Home</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <h2>Our Products</h2>
  <div class="products">
    <?php
    $res = $conn->query("SELECT * FROM products");
    while($row = $res->fetch_assoc()) {
      echo "<div class='product'>
              <img src='{$row['image']}'><br>
              <strong>{$row['name']}</strong><br>
              ₹{$row['price']}<br>
              <a href='add_to_cart.php?id={$row['id']}'>Add to Cart</a>
            </div>";
    }
    ?>
  </div>
  <a href="cart.php">🛒 View Cart</a>
</body>
</html>
