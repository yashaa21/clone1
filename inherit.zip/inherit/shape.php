<?php
// Base class
class Shape {
    public function area() {
        return 0;
    }
}

class Triangle extends Shape {
    public $base, $height;
    public function __construct($base, $height) {
        $this->base = $base;
        $this->height = $height;
    }
    public function area() {
        return 0.5 * $this->base * $this->height;
    }
}

class Square extends Shape {
    public $side;
    public function __construct($side) {
        $this->side = $side;
    }
    public function area() {
        return $this->side * $this->side;
    }
}

class Circle extends Shape {
    public $radius;
    public function __construct($radius) {
        $this->radius = $radius;
    }
    public function area() {
        return pi() * $this->radius * $this->radius;
    }
}

// HTML Output Starts
echo "<!DOCTYPE html><html><head><title>Result</title></head><body>";

if (isset($_POST['submit']) && isset($_POST['shape'])) {
    $shape = $_POST['shape'];
    $obj = null;

    echo "<h2>Selected Shape: " . ucfirst($shape) . "</h2>";

    if ($shape == 'triangle' && isset($_POST['base'], $_POST['height'])) {
        $base = $_POST['base'];
        $height = $_POST['height'];
        $obj = new Triangle($base, $height);
        echo "Base: $base<br>Height: $height<br>";
    } elseif ($shape == 'square' && isset($_POST['side'])) {
        $side = $_POST['side'];
        $obj = new Square($side);
        echo "Side: $side<br>";
    } elseif ($shape == 'circle' && isset($_POST['radius'])) {
        $radius = $_POST['radius'];
        $obj = new Circle($radius);
        echo "Radius: $radius<br>";
    }

    if ($obj) {
        $area = $obj->area();
        echo "<h3>Calculated Area: " . round($area, 2) . "</h3>";
    } else {
        echo "<p style='color:red;'>Please provide all required inputs.</p>";
    }
} else {
    echo "<p style='color:red;'>No shape selected or form not submitted correctly.</p>";
}

echo '<br><a href="index.html">← Go Back</a>';
echo "</body></html>";
?>
