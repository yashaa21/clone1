<?php include "db.php"; ?>

<!DOCTYPE html>
<html>
<head>
  <title>Applicants List</title>
</head>
<body>
  <h2>All Applicants</h2>
  <table border="1" cellpadding="10">
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Email</th>
      <th>Phone</th>
      <th>Course</th>
      <th>Address</th>
      <th>Applied At</th>
    </tr>

    <?php
    $result = $conn->query("SELECT * FROM students ORDER BY created_at DESC");

    while ($row = $result->fetch_assoc()) {
      echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['full_name']}</td>
        <td>{$row['email']}</td>
        <td>{$row['phone']}</td>
        <td>{$row['course']}</td>
        <td>{$row['address']}</td>
        <td>{$row['created_at']}</td>
      </tr>";
    }
    ?>
  </table>
  <br>
  <a href="register.php">← Go Back to Form</a>
</body>
</html>
