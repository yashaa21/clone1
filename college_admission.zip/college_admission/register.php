<?php include "db.php"; ?>

<!DOCTYPE html>
<html>
<head>
  <title>College Admission Form</title>
</head>
<body>
  <h2>Admission Form</h2>
  <form method="post">
    <input type="text" name="full_name" placeholder="Full Name" required><br><br>
    <input type="email" name="email" placeholder="Email" required><br><br>
    <input type="text" name="phone" placeholder="Phone Number" required><br><br>
    
    <select name="course" required>
      <option value="">-- Select Course --</option>
      <option>BSc IT</option>
      <option>BCom</option>
      <option>BA</option>
      <option>BSc CS</option>
    </select><br><br>
    
    <textarea name="address" placeholder="Address" rows="4" cols="30" required></textarea><br><br>
    
    <input type="submit" name="submit" value="Apply Now">
  </form>

  <br><a href="view.php">View Applicants</a>

<?php
if (isset($_POST['submit'])) {
    $name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $course = $_POST['course'];
    $address = $_POST['address'];

    $sql = "INSERT INTO students (full_name, email, phone, course, address)
            VALUES ('$name', '$email', '$phone', '$course', '$address')";

    if ($conn->query($sql)) {
        echo "<p>Application submitted successfully!</p>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
</body>
</html>
