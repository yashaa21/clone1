<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "EmployeeDB");

// Check connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $txtfname = isset($_POST['txtfname']) ? mysqli_real_escape_string($conn, $_POST['txtfname']) : "";
    $txtmname = isset($_POST['mname']) ? mysqli_real_escape_string($conn, $_POST['mname']) : "";
    $txtlname = isset($_POST['lname']) ? mysqli_real_escape_string($conn, $_POST['lname']) : "";
    $txtpwd = isset($_POST['txtpwd']) ? password_hash($_POST['txtpwd'], PASSWORD_DEFAULT) : "";

    if (!empty($txtfname) && !empty($txtlname) && !empty($_POST['txtpwd'])) {
        // Insert data into the database
        $sql = "INSERT INTO Employee_info (fname, mname, lname, pwd) VALUES ('$txtfname', '$txtmname', '$txtlname', '$txtpwd')";
        
        if (mysqli_query($conn, $sql)) {
            echo "<h3>Employee Records Inserted Successfully!</h3>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "<h3>Please fill in all required fields!</h3>";
    }
}

// Fetch and display records
$sql = "SELECT * FROM Employee_info";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "<h2>Employee Records:</h2>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<strong>EMP ID:</strong> " . $row['Id'] . "<br>" .
             "<strong>First Name:</strong> " . htmlspecialchars($row['fname']) . "<br>" .
             "<strong>Middle Name:</strong> " . htmlspecialchars($row['mname']) . "<br>" .
             "<strong>Last Name:</strong> " . htmlspecialchars($row['lname']) . "<br>" .
             "<hr>";
    }
} else {
    echo "No records found.";
}

// Close connection
mysqli_close($conn);
?>
