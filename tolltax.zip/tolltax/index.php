<?php include("db.php"); ?>

<!DOCTYPE html>
<html>
<head>
  <title>Toll Tax Entry</title>
</head>
<body>
  <h2>Toll Entry Form</h2>
  <form method="post">
    <label>Vehicle Number:</label><br>
    <input type="text" name="vehicle_number" required><br><br>

    <label>Vehicle Type:</label><br>
    <select name="vehicle_type" required>
      <option>Car</option>
      <option>Truck</option>
      <option>Bus</option>
      <option>Bike</option>
    </select><br><br>

    <label>Toll Amount:</label><br>
    <input type="number" name="toll_amount" required><br><br>

    <input type="submit" name="submit" value="Submit">
  </form>

  <br>
  <a href="view.php">View All Entries</a>

  <?php
  if (isset($_POST['submit'])) {
    $vnum = $_POST['vehicle_number'];
    $vtype = $_POST['vehicle_type'];
    $amt = $_POST['toll_amount'];

    $sql = "INSERT INTO toll_entries (vehicle_number, vehicle_type, toll_amount)
            VALUES ('$vnum', '$vtype', '$amt')";

    if ($conn->query($sql)) {
      echo "<p>Entry added successfully!</p>";
    } else {
      echo "Error: " . $conn->error;
    }
  }
  ?>
</body>
</html>
