<?php include("db.php"); ?>

<!DOCTYPE html>
<html>
<head>
  <title>View Toll Entries</title>
</head>
<body>
  <h2>Toll Collection Records</h2>
  <table border="1" cellpadding="10">
    <tr>
      <th>ID</th>
      <th>Vehicle Number</th>
      <th>Type</th>
      <th>Amount</th>
      <th>Time</th>
    </tr>

    <?php
    $result = $conn->query("SELECT * FROM toll_entries ORDER BY entry_time DESC");

    while ($row = $result->fetch_assoc()) {
      echo "<tr>
              <td>{$row['id']}</td>
              <td>{$row['vehicle_number']}</td>
              <td>{$row['vehicle_type']}</td>
              <td>{$row['toll_amount']}</td>
              <td>{$row['entry_time']}</td>
            </tr>";
    }
    ?>
  </table>
  <br>
  <a href="index.php">← Go Back</a>
</body>
</html>
