<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Checkout</title>
</head>
<body>
  <h2>Thank You!</h2>
  <p>Your order has been placed.</p>
  <?php session_destroy(); ?>
  <a href="index.php">Back to Home</a>
</body>
</html>
