<?php include "db.php"; ?>

<h2>All Medicines</h2>
<table border="1" cellpadding="10">
  <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Brand</th>
    <th>Qty</th>
    <th>Price</th>
    <th>Expiry</th>
    <th>Action</th>
  </tr>

<?php
$result = $conn->query("SELECT * FROM medicines");
while ($row = $result->fetch_assoc()) {
  echo "<tr>
    <td>{$row['id']}</td>
    <td>{$row['name']}</td>
    <td>{$row['brand']}</td>
    <td>{$row['quantity']}</td>
    <td>{$row['price']}</td>
    <td>{$row['expiry_date']}</td>
    <td>
      <a href='edit.php?id={$row['id']}'>Edit</a> |
      <a href='delete.php?id={$row['id']}'>Delete</a>
    </td>
  </tr>";
}
?>
</table>
<br>
<a href="index.php">← Back to Home</a>
