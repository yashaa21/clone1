<?php include "db.php"; ?>

<h2>Add Medicine</h2>
<form method="post">
  <input type="text" name="name" placeholder="Medicine Name" required><br><br>
  <input type="text" name="brand" placeholder="Brand" required><br><br>
  <input type="number" name="quantity" placeholder="Quantity" required><br><br>
  <input type="text" name="price" placeholder="Price" required><br><br>
  <input type="date" name="expiry_date" required><br><br>
  <input type="submit" name="submit" value="Add Medicine">
</form>

<?php
if (isset($_POST['submit'])) {
  $sql = "INSERT INTO medicines (name, brand, quantity, price, expiry_date)
          VALUES ('$_POST[name]', '$_POST[brand]', $_POST[quantity], $_POST[price], '$_POST[expiry_date]')";

  if ($conn->query($sql)) {
    echo "Medicine added successfully.";
  } else {
    echo "Error: " . $conn->error;
  }
}
?>
