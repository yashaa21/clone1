<?php include "db.php";

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM medicines WHERE id=$id");
$data = $result->fetch_assoc();

if (isset($_POST['update'])) {
  $conn->query("UPDATE medicines SET 
    name='$_POST[name]', brand='$_POST[brand]', quantity=$_POST[quantity],
    price=$_POST[price], expiry_date='$_POST[expiry_date]' WHERE id=$id");

  echo "Updated successfully. <a href='view.php'>Go Back</a>";
  exit();
}
?>

<h2>Edit Medicine</h2>
<form method="post">
  <input type="text" name="name" value="<?= $data['name'] ?>" required><br><br>
  <input type="text" name="brand" value="<?= $data['brand'] ?>" required><br><br>
  <input type="number" name="quantity" value="<?= $data['quantity'] ?>" required><br><br>
  <input type="text" name="price" value="<?= $data['price'] ?>" required><br><br>
  <input type="date" name="expiry_date" value="<?= $data['expiry_date'] ?>" required><br><br>
  <input type="submit" name="update" value="Update">
</form>
