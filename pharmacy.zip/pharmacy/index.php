<!DOCTYPE html>
<html>
<head>
  <title>Pharmacy System</title>
</head>
<body>
  <h2>Pharmacy Management</h2>
  <a href="add.php">Add New Medicine</a> |
  <a href="view.php">View All Medicines</a>
</body>
</html>
