<?php include "db.php"; ?>
<!DOCTYPE html>
<html>
<head>
  <title>View Complaints</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container mt-5">
    <h2>All Complaints</h2>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Complaint</th>
          <th>Submitted At</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $result = $conn->query("SELECT * FROM complaints ORDER BY created_at DESC");
        while ($row = $result->fetch_assoc()) {
          echo "<tr>
                  <td>{$row['id']}</td>
                  <td>{$row['name']}</td>
                  <td>{$row['email']}</td>
                  <td>{$row['complaint']}</td>
                  <td>{$row['created_at']}</td>
                </tr>";
        }
        ?>
      </tbody>
    </table>
    <a href="index.php" class="btn btn-secondary">Go Back</a>
  </div>
</body>
</html>
