<!DOCTYPE html>
<html>
<head>
  <title>Complaint Form</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container mt-5">
    <h2>Submit a Complaint</h2>
    <form action="submit.php" method="POST">
      <div class="mb-3">
        <label>Name</label>
        <input type="text" name="name" required class="form-control">
      </div>
      <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" required class="form-control">
      </div>
      <div class="mb-3">
        <label>Complaint</label>
        <textarea name="complaint" rows="4" required class="form-control"></textarea>
      </div>
      <button type="submit" class="btn btn-primary">Submit Complaint</button>
    </form>
    <br>
    <a href="view_complaints.php" class="btn btn-secondary">View Complaints (Admin)</a>
  </div>
</body>
</html>
