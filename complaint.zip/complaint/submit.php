<?php
include "db.php";

$name = $_POST['name'];
$email = $_POST['email'];
$complaint = $_POST['complaint'];

$sql = "INSERT INTO complaints (name, email, complaint) VALUES ('$name', '$email', '$complaint')";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Complaint submitted successfully!');window.location='index.php';</script>";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
